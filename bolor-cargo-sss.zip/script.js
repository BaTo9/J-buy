(function() {
  var DEFAULT_LANG = 'mn';
  var currentLang = DEFAULT_LANG;

  /* ---------- localStorage (алдаа гарвал сайт ажилласаар байна) ---------- */
  function store(key, value) {
    try { localStorage.setItem(key, value); } catch (e) {}
  }

  function read(key) {
    try { return localStorage.getItem(key); } catch (e) { return null; }
  }

  /* ---------- Орчуулга ---------- */
  function t(key) {
    var all = window.I18N || {};
    var cur = all[currentLang] || {};
    if (cur[key] !== undefined) return cur[key];
    var base = all[DEFAULT_LANG] || {};
    return base[key];
  }

  function each(selector, fn) {
    document.querySelectorAll(selector).forEach(fn);
  }

  function applyLang(lang) {
    if (!window.I18N || !window.I18N[lang]) lang = DEFAULT_LANG;
    currentLang = lang;
    document.documentElement.lang = lang;

    each('[data-i18n]', function(el) {
      var v = t(el.getAttribute('data-i18n'));
      if (v !== undefined) el.textContent = v;
    });
    each('[data-i18n-html]', function(el) {
      var v = t(el.getAttribute('data-i18n-html'));
      if (v !== undefined) el.innerHTML = v;
    });
    each('[data-i18n-placeholder]', function(el) {
      var v = t(el.getAttribute('data-i18n-placeholder'));
      if (v !== undefined) el.setAttribute('placeholder', v);
    });
    each('[data-i18n-aria]', function(el) {
      var v = t(el.getAttribute('data-i18n-aria'));
      if (v !== undefined) el.setAttribute('aria-label', v);
    });
    each('[data-i18n-alt]', function(el) {
      var v = t(el.getAttribute('data-i18n-alt'));
      if (v !== undefined) el.setAttribute('alt', v);
    });

    var title = t('meta.title');
    if (title) document.title = title;
    var meta = document.querySelector('meta[name="description"]');
    if (meta && t('meta.desc')) meta.setAttribute('content', t('meta.desc'));

    each('.lang-option', function(opt) {
      opt.setAttribute('aria-selected', String(opt.getAttribute('data-lang') === lang));
    });
    var flagUse = document.getElementById('langFlagUse');
    if (flagUse) flagUse.setAttribute('href', '#flag-' + lang);

    store('lang', lang);
    updateThemeUi();
  }

  /* ---------- Харанхуй горим ---------- */
  function currentTheme() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }

  function updateThemeUi() {
    var btn = document.getElementById('themeToggle');
    var icon = document.getElementById('themeIcon');
    if (!btn || !icon) return;
    var dark = currentTheme() === 'dark';
    icon.className = dark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
    btn.setAttribute('aria-pressed', String(dark));
    var label = t(dark ? 'aria.themeLight' : 'aria.themeDark');
    if (label) btn.setAttribute('aria-label', label);
  }

  function applyTheme(theme, save) {
    document.documentElement.setAttribute('data-theme', theme);
    if (save) store('theme', theme);
    updateThemeUi();
  }

  document.addEventListener('DOMContentLoaded', function() {
    /* Хэл */
    var savedLang = read('lang');
    applyLang(savedLang && window.I18N && window.I18N[savedLang] ? savedLang : DEFAULT_LANG);

    var langToggle = document.getElementById('langToggle');
    var langMenu = document.getElementById('langMenu');

    function setLangMenu(open) {
      if (!langToggle || !langMenu) return;
      langMenu.hidden = !open;
      langToggle.setAttribute('aria-expanded', String(open));
    }

    if (langToggle && langMenu) {
      langToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        setLangMenu(langMenu.hidden);
      });

      each('.lang-option', function(opt) {
        opt.addEventListener('click', function() {
          applyLang(opt.getAttribute('data-lang'));
          setLangMenu(false);
          langToggle.focus();
        });
      });

      document.addEventListener('click', function(e) {
        if (!langMenu.hidden && !langMenu.contains(e.target)) setLangMenu(false);
      });

      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !langMenu.hidden) {
          setLangMenu(false);
          langToggle.focus();
        }
      });
    }

    /* Харанхуй горим */
    var themeBtn = document.getElementById('themeToggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', function() {
        applyTheme(currentTheme() === 'dark' ? 'light' : 'dark', true);
      });
    }
    if (window.matchMedia) {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      var onChange = function(e) {
        if (!read('theme')) applyTheme(e.matches ? 'dark' : 'light', false);
      };
      if (mq.addEventListener) mq.addEventListener('change', onChange);
    }
    updateThemeUi();

    /* Гар утасны цэс */
    var burger = document.querySelector('.hamburger-menu');
    var menu = document.querySelector('.menu');

    function setMenu(open) {
      if (!menu || !burger) return;
      menu.classList.toggle('active', open);
      burger.classList.toggle('active', open);
      burger.setAttribute('aria-expanded', String(open));
    }

    if (burger && menu) {
      burger.addEventListener('click', function() {
        setMenu(!menu.classList.contains('active'));
      });
      burger.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          setMenu(!menu.classList.contains('active'));
        }
      });
      menu.querySelectorAll('a[href^="#"]').forEach(function(link) {
        link.addEventListener('click', function() { setMenu(false); });
      });
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') setMenu(false);
      });
    }

    /* Дэлгэрэнгүй цонх */
    var detailBtn = document.getElementById('detailBtn');
    var detailDialog = document.getElementById('detailDialog');
    var detailClose = document.getElementById('detailClose');
    if (detailBtn && detailDialog && typeof detailDialog.showModal === 'function') {
      detailBtn.addEventListener('click', function() { detailDialog.showModal(); });
      if (detailClose) {
        detailClose.addEventListener('click', function() { detailDialog.close(); });
      }
      detailDialog.addEventListener('click', function(e) {
        if (e.target === detailDialog) detailDialog.close();
      });
    }

    /* "Дээш буцах" товч */
    var topBtn = document.getElementById('gotopBtn');
    if (topBtn) {
      window.addEventListener('scroll', function() {
        topBtn.classList.toggle('active', window.scrollY > 300);
      }, { passive: true });

      topBtn.addEventListener('click', function(e) {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  });
})();
