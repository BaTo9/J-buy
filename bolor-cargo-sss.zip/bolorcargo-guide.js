/* BOLORCARGO GUIDE — modal, tabs and contact links */

(() => {
  "use strict";

  const modal = document.getElementById("bc-guide-modal");
  if (!modal || modal.dataset.ready === "true") return;

  modal.dataset.ready = "true";

  const closeButton = modal.querySelector(".bcg-close");
  let previousFocus = null;

  function openGuide() {
    previousFocus = document.activeElement;
    modal.classList.add("bcg-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("bcg-no-scroll");
    closeButton.focus();
  }

  function closeGuide() {
    modal.classList.remove("bcg-open");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("bcg-no-scroll");

    if (previousFocus && typeof previousFocus.focus === "function") {
      previousFocus.focus();
    }
  }

  document.querySelectorAll("[data-bc-guide-open]").forEach((button) => {
    button.addEventListener("click", openGuide);
  });

  modal.querySelectorAll("[data-bc-guide-close]").forEach((button) => {
    button.addEventListener("click", closeGuide);
  });

  document.addEventListener("keydown", (event) => {
    if (!modal.classList.contains("bcg-open")) return;

    if (event.key === "Escape") {
      closeGuide();
    }

    if (event.key === "Tab") {
      const focusable = Array.from(
        modal.querySelectorAll(
          'button:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'
        )
      ).filter((element) => element.offsetParent !== null);

      if (!focusable.length) return;

      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });

  /* ---------- Табууд ---------- */
  const tabs = modal.querySelectorAll("[data-bcg-tab]");
  const panels = modal.querySelectorAll("[data-bcg-panel]");

  function activateTab(tab) {
    const name = tab.dataset.bcgTab;

    tabs.forEach((item) => {
      const active = item === tab;
      item.classList.toggle("is-active", active);
      item.setAttribute("aria-selected", String(active));
    });

    panels.forEach((panel) => {
      panel.hidden = panel.dataset.bcgPanel !== name;
    });
  }

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => activateTab(tab));
  });

  /* ---------- Холбоо барих мэдээлэл ---------- */
  const contact = {
    phone: "+81 90-3407-2919",
    email: "bolorcargo77@gmail.com",
    facebook: "https://m.facebook.com" // өөрийн хуудасны холбоосоор солино
  };

  const phone = modal.querySelector('[data-bcg-contact="phone"]');
  const email = modal.querySelector('[data-bcg-contact="email"]');
  const facebook = modal.querySelector('[data-bcg-contact="facebook"]');

  if (phone) {
    if (contact.phone.trim()) {
      phone.href = "tel:" + contact.phone.replace(/[^\d+]/g, "");
      phone.querySelector("strong").textContent = contact.phone;
    } else {
      phone.removeAttribute("href");
    }
  }

  if (email) {
    if (contact.email.trim()) {
      email.href = "mailto:" + contact.email.trim();
      email.querySelector("strong").textContent = contact.email;
    } else {
      email.removeAttribute("href");
    }
  }

  if (facebook) {
    if (contact.facebook.trim()) {
      facebook.href = contact.facebook.trim();
      facebook.target = "_blank";
      facebook.rel = "noopener noreferrer";
    } else {
      facebook.removeAttribute("href");
      facebook.querySelector("strong").textContent = "Тохируулаагүй";
    }
  }
})();
